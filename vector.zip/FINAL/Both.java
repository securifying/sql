import java.util.Vector;

public class MainServer {
	public static void main(String[] args) {
		int pages[] = {7, 0, 1, 2, 
                0, 3, 0, 4, 2, 3, 0, 3, 2};
		int cacheSize = 4;
		lru(pages, cacheSize);
		optimal(pages, cacheSize);
	}
	public static void lru(int pages[], int cacheSize){
		System.out.println("Using LRU");
		Vector<Integer> cache = new Vector<Integer>();
		int hit = 0;
		int miss = 0;
		for (int i: pages) {
			if(cache.contains(i))
			{
				int loc = cache.indexOf(i);
				cache.remove(loc);
				cache.add(i);
				hit++;
			}
			else{
				if(cache.size() >= cacheSize){
					cache.remove(0);
					cache.add(i);
					miss++;
				}
				else{
					cache.add(i);
					miss++;
				}
				
			}
		}
		System.out.println("Hit : " + hit);
		System.out.println("Miss : " + miss);
		System.out.println("");
	}
	public static void optimal(int pages[], int cacheSize){
		System.out.println("Using Optimal");
		Vector<Integer> cache = new Vector<Integer>();
		int hit = 0;
		int miss = 0;
		for(int i=0 ; i< pages.length; i++)
		{
			if(cache.contains(pages[i]))
			{
				hit++;
			}
			else{
					if (cache.size() >= cacheSize)
					{
						Vector<Integer> searchVector = getLimitedVector(pages, i);
						int replace = getReplacement(cache, searchVector);
						int loc = cache.indexOf(replace);
						cache.remove(loc);
						cache.add(pages[i]);
						miss++;
					}
					else
					{
						cache.add(pages[i]);
						miss++;
					}
				}
		}
		
		System.out.println("Hit : " + hit);
		System.out.println("Miss : " + miss);
		System.out.println("");
	}
	public static int getReplacement(Vector<Integer> cache, Vector<Integer> search ){
		Vector<Integer> copyCache = (Vector<Integer>) cache.clone();
		for (int i : search)
		{
			if(copyCache.size() > 1)
			{
				if(copyCache.contains(i))
				{
					copyCache.removeElement(i);
				}
			}
		}
		return copyCache.firstElement();
	}
	public static Vector<Integer> getLimitedVector(int pages[], int index){
		Vector<Integer> out = new Vector<Integer>();
		for(int i=index+1 ; i< pages.length; i++){
			out.add(pages[i]);
		}
		return out;
	}
}