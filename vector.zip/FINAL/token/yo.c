#include <stdio.h>
int main(int argc, char const *argv[])
{
	printf("   \"%s\"  ,  mathematical operator","+");
	return 0;
}