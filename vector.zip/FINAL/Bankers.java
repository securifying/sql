
public class Bankers {
	public static void main(String args[]) {
		// Number of processes 
		int P = 5; 
		  
		// Number of resources 
		int R = 3;
				
		int processes[] = {0, 1, 2, 3, 4}; 
		  
	    // Available instances of resources 
	    int avail[] = {3, 3, 2}; 
	  
	    // Maximum R that can be allocated 
	    // to processes 
	    int maxm[][] = {{7, 5, 3}, 
	                     {3, 2, 2}, 
	                     {9, 0, 2}, 
	                     {2, 2, 2}, 
	                     {4, 3, 3}}; 
	  
	    // Resources allocated to processes 
	    int allot[][] = {{0, 1, 0}, 
	                      {2, 0, 0}, 
	                      {3, 0, 2}, 
	                      {2, 1, 1}, 
	                      {0, 0, 2}}; 
	  
		
	    int[][] need = new int[P][R];
	    boolean[] finished = new boolean[P];
	    int[] safeSeq = new int[P];
	    
	    // Calculating need matrix
	    for(int i=0;i<P;i++) {
	    	for(int j=0;j<R;j++) {
	    		need[i][j] = maxm[i][j] - allot[i][j];
	    	}
	    }
	    
	    int work[] = avail.clone();
		int count = 0;
		boolean found = false;
		while(count < P) 
		{
			found = false;
			for(int p=0;p<P;p++) 
			{
				if(finished[p] == false) 
				{
					int j;
					for(j=0;j<R;j++) 
					{
						if(need[p][j] > work[j])
							break;
					}
					if(j == R) 
					{
						for(int k=0;k<R;k++)
							work[k]+=allot[p][k];
						safeSeq[count++] = p;
						finished[p] = true;
						found = true;
					}
				}
			}
		}
		if(found == false) {
			System.out.println("System is not in safe state!");
		}
		else {
			System.out.println("System is in safe state!");
			for(int i=0;i<P;i++) {
				System.out.println(safeSeq[i]);
			}
		}
		
	    
	}
}
