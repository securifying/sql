public class AddTwoIntegers {

    public static void main() {
        
        int first = 10;
        int second = 20;
        int 2a;
        int sum = first + second;

        System.out.println("The sum is: " + sum);
    }
}